<?php

$server_mail ="image@employ-id.1is.pro"; /*Enter Your Email Here*/

?>